"# laybox2SG" 

配置表 json生成工具
cnjson.bat
需要 apache-ant  https://ant.apache.org/manual/index.html

