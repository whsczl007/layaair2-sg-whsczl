export default class AppConfig {

    public static isDebug: boolean = true;
    public static HallScene: any = "moduleView/hall/HallScene.scene";
}