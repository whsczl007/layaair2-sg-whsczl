export default class DropVO {

    /** 解锁英雄ID */
    public unlockNeedId: number = 0;
    /** 掉落ID */
    public dropHeroLevel: number = 0;

}