export default class LotteryRosterVO {
    public id: number;
    public lotteryName: string;
    public lotterydata: string;
}