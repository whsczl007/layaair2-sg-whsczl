export default class MapVO {

    public id: number;
    /** 0:金  1：木  2：水  3：火   4：土 */
    public type: number;
    /** 城池名字 */
    public name: string;
}