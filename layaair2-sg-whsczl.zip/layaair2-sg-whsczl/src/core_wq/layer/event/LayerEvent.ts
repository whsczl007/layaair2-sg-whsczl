export default class LayerEvent {
    
    public static CHILD_ADDED: string = "CHILD_ADDED";
    public static CHILD_REMOVED: string = "CHILD_REMOVED";
    public static LAYER_ANIMATION_COMPLETE: string = "LAYER_ANIMATION_COMPLETE";
}