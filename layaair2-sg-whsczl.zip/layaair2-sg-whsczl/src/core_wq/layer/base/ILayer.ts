export default interface ILayer {
    getLayerId(): number;
}